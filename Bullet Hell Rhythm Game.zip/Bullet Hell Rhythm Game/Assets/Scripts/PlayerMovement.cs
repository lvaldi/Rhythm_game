﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary {
	public float xMin, xMax, zMin, zMax;
}

public class PlayerMovement : MonoBehaviour 
{
	public float speed;
	public Boundary boundary;
	public GameObject player;

	public GameObject Shot;
	public Transform BulletSpawn;
	public float fireRate;
	private float nextFire;

	void Update() {

        if (Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
			Instantiate(Shot, BulletSpawn.position, BulletSpawn.rotation);
        }
	}

	void FixedUpdate ()
	{
		if (Input.GetKey("right") || Input.GetKey("d")) {
			transform.Translate(speed, 0, 0);
		}
		if (Input.GetKey("left") || Input.GetKey("a")) {
			transform.Translate(-speed, 0, 0);
		}
		if (Input.GetKey("up") || Input.GetKey("w")) {
			transform.Translate(0, 0, speed);
		}
		if (Input.GetKey("down") || Input.GetKey("s")) {
			transform.Translate(0, 0, -speed);
		}	

		player = GameObject.FindGameObjectWithTag("Player");

		player.transform.position = new Vector3 
		(Mathf.Clamp (player.transform.position.x, boundary.xMin, boundary.xMax), 
		0.25f, 
		Mathf.Clamp (player.transform.position.z, boundary.zMin, boundary.zMax));
	}
}