﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyPlayer : MonoBehaviour {

	public int damage = 1;
	GameObject PlayerObject;
	PlayerHealth playerHealth;


	void Awake() {
		PlayerObject = GameObject.FindGameObjectWithTag("Player");
		playerHealth = PlayerObject.GetComponent<PlayerHealth>();
		if (playerHealth) {
       		Debug.Log("GameObject found, reference is not null");
		} else {
			Debug.Log("Cannot find GameObject, reference is null");
		}
}

	void OnTriggerEnter(Collider other) {
		if (other.gameObject == PlayerObject) {
			playerHealth.TakeDamage(damage);
			Destroy (gameObject);
		}
	}
}
