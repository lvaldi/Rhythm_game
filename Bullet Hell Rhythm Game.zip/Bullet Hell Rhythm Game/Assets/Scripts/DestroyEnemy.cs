using UnityEngine;
using System.Collections;

public class DestroyEnemy : MonoBehaviour {
    public int attackDamage = 1;
    GameObject PlayerObject;
    EnemyHealth enemyHealth;

    void Awake() {
        PlayerObject = GameObject.FindGameObjectWithTag ("Enemy");
        enemyHealth = PlayerObject.GetComponent <EnemyHealth> ();
    }

    void OnTriggerEnter (Collider other)
    {
        if (other.gameObject == PlayerObject) {
            enemyHealth.TakeDamage (attackDamage);
            Destroy (gameObject);
        }
    }
}